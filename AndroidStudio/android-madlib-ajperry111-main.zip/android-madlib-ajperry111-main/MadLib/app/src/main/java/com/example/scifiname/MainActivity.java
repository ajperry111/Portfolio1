package com.example.scifiname;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
/* **Mad Lib 1: The Picnic Surprise**
Had chatgpt write this madlib using the same inputs from the sonic one

Once upon a time, on a sunny and *adjective1* day, I decided to have a picnic in the park. I packed a basket full of *pluralnoun1*, *adjective2* sandwiches, and a thermos filled with *color1* lemonade. As I spread out my *color2* picnic blanket under a *adjective3* tree, I noticed a group of *pluralnoun2* nearby.

They were playing with a *noun1*, which was a bright *color2* color, and laughing loudly. I couldn't help but smile as I watched them. After a while, I decided to share some of my *number1* sandwiches with them. We all had a great time, and I made *number2* new friends that day.

**Mad Lib 2: The Haunted House**
Had chatgpt write this madlib using the same inputs from the sonic one

Last night, I dared to enter the *adjective1* abandoned house at the end of the street. It was a dark and *adjective2* night, with a full moon casting eerie shadows. The old house was rumored to be haunted by *pluralnoun1*, and its creaky floorboards made spine-tingling sounds.

As I explored the house, I discovered *number1* *noun1* in the dusty attic. They were covered in cobwebs and had a mysterious *color1* glow. Suddenly, I heard footsteps and saw *number2* pairs of *color2* eyes in the darkness. I knew I had to *verb* out of there as fast as I could!

**Mad Lib 3: A Palace Fit For A HedgeHog**
Found this madlib on https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.readbrightly.com%2Fmad-libs-printables-activities%2F&psig=AOvVaw2C_1B3eUxbG7jfhM5DU0yg&ust=1695322123257000&source=images&cd=vfe&opi=89978449&ved=0CBAQ3YkBahcKEwiQlr-c7bmBAxUAAAAAHQAAAAAQAw

Sonic's abode is a very *adjective1* place. At first glance, it seems like a/an *adjective2* cave, but if you look closer, you'll see it's actually a comfortable *noun1*. For one, Sonic has a super-cozy beanbag *noun2*. When he feels like listening to some *adjective3* tunes from the 1980s, Sonic turns on his old-school *noun3*, pulls out his collection of *pluralnoun1*, and jams out. In addition to great tunes, Sonic has plenty of *adjective4* equipment to keep him busy. There's a dryer that Sonic uses as a treadmill to run *number1* miles a day. He has a/an *color1* Ping-Pong table where he plays against...himself. (His record is *number2* wins and zero losses!) And for that final touch, Sonic hung *pluralnoun2* all over his cave walls. He's got a/an *adjective5* photo of (the) *place1* next to a/an *color2* poster of *pluralnoun3*. It may not be much, but Sonic loves to *verb1* in his cave all the time!
*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect a java object to the widget
        EditText Adjective1 = findViewById(R.id.adjective1EditText);
        EditText Adjective2 = findViewById(R.id.adjective2EditText);
        EditText Noun1 = findViewById(R.id.noun1EditText);
        EditText Noun2 = findViewById(R.id.noun2EditText);
        EditText Adjective3 = findViewById(R.id.adjective3EditText);
        EditText Noun3 = findViewById(R.id.noun3EditText);
        EditText PluralNoun1 = findViewById(R.id.pluralNoun1EditText);
        EditText Adjective4 = findViewById(R.id.adjective4EditText);
        EditText Number1 = findViewById(R.id.number1EditText);
        EditText Color1 = findViewById(R.id.color1EditText);
        EditText Number2 = findViewById(R.id.number2EditText);
        EditText PluralNoun2 = findViewById(R.id.pluralNoun2EditText);
        EditText Adjective5 = findViewById(R.id.adjective5EditText);
        EditText Place1 = findViewById(R.id.place1EditText);
        EditText Color2 = findViewById(R.id.color2EditText);
        EditText PluralNoun3 = findViewById(R.id.pluralNoun3EditText);
        EditText Verb1 = findViewById(R.id.verb1EditText);
        Button SonicBTN = findViewById(R.id.sonicBTN);
        Button PicnicBTN = findViewById(R.id.picnicBTN);
        Button HauntedHouseBTN = findViewById(R.id.hauntedHouseBTN);
        Button RandomBTN = findViewById(R.id.randomBTN);
        TextView outputTXT = findViewById(R.id.outputTextView);

        RandomBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String adjective1 = String.valueOf(Adjective1.getText());
                String adjective2 = String.valueOf(Adjective2.getText());
                String noun2 = String.valueOf(Noun2.getText());
                String adjective3 = String.valueOf(Adjective3.getText());
                String noun3 = String.valueOf(Noun3.getText());
                String pluralNoun1 = String.valueOf(PluralNoun1.getText());
                String adjective4 = String.valueOf(Adjective4.getText());
                String number1 = String.valueOf(Number1.getText());
                String color1 = String.valueOf(Color1.getText());
                String number2 = String.valueOf(Number2.getText());
                String pluralNoun2 = String.valueOf(PluralNoun2.getText());
                String adjective5 = String.valueOf(Adjective5.getText());
                String place1 = String.valueOf(Place1.getText());
                String color2 = String.valueOf(Color2.getText());
                String pluralNoun3 = String.valueOf(PluralNoun3.getText());
                String verb1 = String.valueOf(Verb1.getText());
                String noun1 = String.valueOf(Noun1.getText());
                Random randy = new Random();
                int randomInt = randy.nextInt(3);
                if (randomInt==1) {
                    outputTXT.setText("**Mad Lib 1: The Picnic Surprise** Once upon a time, on a sunny and " + adjective1 + " day, I decided to have a picnic in the park. I packed a basket full of " + pluralNoun1 + ", " + adjective2 + " sandwiches, and a thermos filled with " + color1 + " lemonade. As I spread out my " + color2 + " picnic blanket under a " + adjective3 + " tree, I noticed a group of " + pluralNoun2 + " nearby. They were playing with a " + noun1 + ", which was a bright" + color2 + "color, and laughing loudly. I couldn't help but smile as I watched them. After a while, I decided to share some of my " + number1 + " sandwiches with them. We all had a great time, and I made " + number2 + " new friends that day.");
                }else if(randomInt==2){
                    outputTXT.setText("**Mad Lib 2: The Haunted House** Last night, I dared to enter the "+adjective1+" abandoned house at the end of the street. It was a dark and "+adjective2+" night, with a full moon casting eerie shadows. The old house was rumored to be haunted by "+pluralNoun1+", and its creaky floorboards made spine-tingling sounds. As I explored the house, I discovered "+number1+" "+noun1+" in the dusty attic. They were covered in cobwebs and had a mysterious "+color1+" glow. Suddenly, I heard footsteps and saw "+number2+" pairs of "+color2+" eyes in the darkness. I knew I had to "+verb1+" out of there as fast as I could!");
                }else if(randomInt==3){
                    outputTXT.setText("**Mad Lib 3: A Palace Fit For A HedgeHog** Sonic's abode is a very "+adjective1+" place. At first glance, it seems like a/an "+adjective2+" cave, but if you look closer, you'll see it's actually a comfortable "+noun1+". For one, Sonic has a super-cozy beanbag "+noun2+". When he feels like listening to some "+adjective3+" tunes from the 1980s, Sonic turns on his old-school "+noun3+", pulls out his collection of "+pluralNoun1+", and jams out. In addition to great tunes, Sonic has plenty of "+adjective4+" equipment to keep him busy. There's a dryer that Sonic uses as a treadmill to run "+number1+" miles a day. He has a/an "+color1+" Ping-Pong table where he plays against...himself. (His record is "+number2+" wins and zero losses!) And for that final touch, Sonic hung "+pluralNoun2+" all over his cave walls. He's got a/an "+adjective5+" photo of (the) "+place1+" next to a/an "+color2+" poster of "+pluralNoun3+". It may not be much, but Sonic loves to "+verb1+" in his cave all the time!");
                }
            }
        });
        PicnicBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random randy = new Random();
                String adjective1 = String.valueOf(Adjective1.getText());
                String adjective2 = String.valueOf(Adjective2.getText());
                String noun2 = String.valueOf(Noun2.getText());
                String adjective3 = String.valueOf(Adjective3.getText());
                String noun3 = String.valueOf(Noun3.getText());
                String pluralNoun1 = String.valueOf(PluralNoun1.getText());
                String adjective4 = String.valueOf(Adjective4.getText());
                String number1 = String.valueOf(Number1.getText());
                String color1 = String.valueOf(Color1.getText());
                String number2 = String.valueOf(Number2.getText());
                String pluralNoun2 = String.valueOf(PluralNoun2.getText());
                String adjective5 = String.valueOf(Adjective5.getText());
                String place1 = String.valueOf(Place1.getText());
                String color2 = String.valueOf(Color2.getText());
                String pluralNoun3 = String.valueOf(PluralNoun3.getText());
                String verb1 = String.valueOf(Verb1.getText());
                String noun1 = String.valueOf(Noun1.getText());
                outputTXT.setText("**Mad Lib 1: The Picnic Surprise** Once upon a time, on a sunny and "+adjective1+" day, I decided to have a picnic in the park. I packed a basket full of "+pluralNoun1+", "+adjective2+" sandwiches, and a thermos filled with "+color1+" lemonade. As I spread out my "+color2+" picnic blanket under a "+adjective3+" tree, I noticed a group of "+pluralNoun2+" nearby. They were playing with a "+noun1+", which was a bright"+color2+"color, and laughing loudly. I couldn't help but smile as I watched them. After a while, I decided to share some of my "+number1+" sandwiches with them. We all had a great time, and I made "+number2+" new friends that day.");
            }
        });
        HauntedHouseBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random randy = new Random();
                String adjective1 = String.valueOf(Adjective1.getText());
                String adjective2 = String.valueOf(Adjective2.getText());
                String noun2 = String.valueOf(Noun2.getText());
                String adjective3 = String.valueOf(Adjective3.getText());
                String noun3 = String.valueOf(Noun3.getText());
                String pluralNoun1 = String.valueOf(PluralNoun1.getText());
                String adjective4 = String.valueOf(Adjective4.getText());
                String number1 = String.valueOf(Number1.getText());
                String color1 = String.valueOf(Color1.getText());
                String number2 = String.valueOf(Number2.getText());
                String pluralNoun2 = String.valueOf(PluralNoun2.getText());
                String adjective5 = String.valueOf(Adjective5.getText());
                String place1 = String.valueOf(Place1.getText());
                String color2 = String.valueOf(Color2.getText());
                String pluralNoun3 = String.valueOf(PluralNoun3.getText());
                String verb1 = String.valueOf(Verb1.getText());
                String noun1 = String.valueOf(Noun1.getText());
                outputTXT.setText("**Mad Lib 2: The Haunted House** Last night, I dared to enter the "+adjective1+" abandoned house at the end of the street. It was a dark and "+adjective2+" night, with a full moon casting eerie shadows. The old house was rumored to be haunted by "+pluralNoun1+", and its creaky floorboards made spine-tingling sounds. As I explored the house, I discovered "+number1+" "+noun1+" in the dusty attic. They were covered in cobwebs and had a mysterious "+color1+" glow. Suddenly, I heard footsteps and saw "+number2+" pairs of "+color2+" eyes in the darkness. I knew I had to "+verb1+" out of there as fast as I could!");
            }
        });
        SonicBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random randy = new Random();
                String adjective1 = String.valueOf(Adjective1.getText());
                String adjective2 = String.valueOf(Adjective2.getText());
                String noun2 = String.valueOf(Noun2.getText());
                String adjective3 = String.valueOf(Adjective3.getText());
                String noun3 = String.valueOf(Noun3.getText());
                String pluralNoun1 = String.valueOf(PluralNoun1.getText());
                String adjective4 = String.valueOf(Adjective4.getText());
                String number1 = String.valueOf(Number1.getText());
                String color1 = String.valueOf(Color1.getText());
                String number2 = String.valueOf(Number2.getText());
                String pluralNoun2 = String.valueOf(PluralNoun2.getText());
                String adjective5 = String.valueOf(Adjective5.getText());
                String place1 = String.valueOf(Place1.getText());
                String color2 = String.valueOf(Color1.getText());
                String pluralNoun3 = String.valueOf(PluralNoun3.getText());
                String verb1 = String.valueOf(Verb1.getText());
                String noun1 = String.valueOf(Noun1.getText());
                outputTXT.setText("**Mad Lib 3: A Palace Fit For A HedgeHog** Sonic's abode is a very "+adjective1+" place. At first glance, it seems like a/an "+adjective2+" cave, but if you look closer, you'll see it's actually a comfortable "+noun1+". For one, Sonic has a super-cozy beanbag "+noun2+". When he feels like listening to some "+adjective3+" tunes from the 1980s, Sonic turns on his old-school "+noun3+", pulls out his collection of "+pluralNoun1+", and jams out. In addition to great tunes, Sonic has plenty of "+adjective4+" equipment to keep him busy. There's a dryer that Sonic uses as a treadmill to run "+number1+" miles a day. He has a/an "+color1+" Ping-Pong table where he plays against...himself. (His record is "+number2+" wins and zero losses!) And for that final touch, Sonic hung "+pluralNoun2+" all over his cave walls. He's got a/an "+adjective5+" photo of (the) "+place1+" next to a/an "+color2+" poster of "+pluralNoun3+". It may not be much, but Sonic loves to "+verb1+" in his cave all the time!");
            }
        });

    }

    }
